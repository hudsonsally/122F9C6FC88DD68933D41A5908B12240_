def factorial(n):
  if n == 0:
    return 1
  else:
    return n * factorial(n - 1)
n=int(input("Enter the number you want to find factorial for : "))
print(factorial(n))
